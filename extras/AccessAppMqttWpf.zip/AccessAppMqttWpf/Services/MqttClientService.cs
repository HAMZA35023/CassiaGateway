using MQTTnet;
using MQTTnet.Client;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace AccessAppMqttWpf.Services;

public sealed class MqttClientService : IDisposable
{
    private readonly IMqttClient _client;
    private readonly MqttFactory _factory = new();
    private CancellationTokenSource? _cts;

    public bool IsConnected => _client?.IsConnected == true;

    public event Action<string, string>? Message;              // topic, payload
    public event Action<bool, string>? ConnectionChanged;      // isConnected, status text

    public MqttClientService()
    {
        _client = _factory.CreateMqttClient();

        _client.ConnectedAsync += _ =>
        {
            ConnectionChanged?.Invoke(true, "Connected");
            return Task.CompletedTask;
        };

        _client.DisconnectedAsync += e =>
        {
            ConnectionChanged?.Invoke(false, $"Disconnected: {e.Reason} {e.ReasonString}".Trim());
            return Task.CompletedTask;
        };

        _client.ApplicationMessageReceivedAsync += e =>
        {
            try
            {
                var payload = e.ApplicationMessage.PayloadSegment.Array == null
                    ? string.Empty
                    : Encoding.UTF8.GetString(e.ApplicationMessage.PayloadSegment);

                Message?.Invoke(e.ApplicationMessage.Topic, payload);
            }
            catch { /* ignore */ }

            return Task.CompletedTask;
        };
    }

    public async Task ConnectAsync(
        string host,
        int port,
        string user,
        string pass,
        bool useTls,
        bool ignoreTlsErrors,
        string subscribeTopic,
        CancellationToken ct)
    {
        _cts?.Cancel();
        _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);

        var builder = new MqttClientOptionsBuilder()
            .WithClientId($"accessapp-wpf-{Environment.MachineName}-{Guid.NewGuid():N}".Substring(0, 32))
            .WithTcpServer(host, port)
            .WithCleanSession();

        if (!string.IsNullOrWhiteSpace(user))
            builder = builder.WithCredentials(user, pass);

        if (useTls)
            TryConfigureTls(builder, ignoreTlsErrors);

        var options = builder.Build();

        ConnectionChanged?.Invoke(false, "Connecting…");
        await _client.ConnectAsync(options, _cts.Token).ConfigureAwait(false);

        if (!string.IsNullOrWhiteSpace(subscribeTopic))
            await _client.SubscribeAsync(subscribeTopic).ConfigureAwait(false);
    }

    /// <summary>
    /// Enables TLS and optionally ignores certificate validation.
    /// Uses reflection/expressions to avoid binding to MQTTnet's TLS builder types at compile time.
    /// </summary>
    private static void TryConfigureTls(MqttClientOptionsBuilder builder, bool ignoreTlsErrors)
    {
        try
        {
            var bt = builder.GetType();

            // Look for: WithTlsOptions(Action<TlsOptionsBuilder>)
            var withTlsOptions = bt.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .FirstOrDefault(m =>
                    m.Name == "WithTlsOptions" &&
                    m.GetParameters().Length == 1 &&
                    m.GetParameters()[0].ParameterType.IsGenericType &&
                    m.GetParameters()[0].ParameterType.GetGenericTypeDefinition() == typeof(Action<>));

            if (withTlsOptions != null)
            {
                var actionType = withTlsOptions.GetParameters()[0].ParameterType;
                var tlsBuilderType = actionType.GetGenericArguments()[0];

                var del = BuildTlsConfiguratorDelegate(actionType, tlsBuilderType, ignoreTlsErrors);
                withTlsOptions.Invoke(builder, new object[] { del });
                return;
            }

            // Some builds expose WithTls() (parameterless)
            var withTls = bt.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .FirstOrDefault(m => m.Name == "WithTls" && m.GetParameters().Length == 0);

            withTls?.Invoke(builder, Array.Empty<object>());
        }
        catch
        {
            // best-effort; if TLS API differs, app still runs (but TLS won't be enabled)
        }
    }

    private static object BuildTlsConfiguratorDelegate(Type actionType, Type tlsBuilderType, bool ignoreTlsErrors)
    {
        // Build: (TlsBuilder x) => { x.UseTls = true / x.UseTls(true); set validation handler => true; set ignore flags; }
        var p = Expression.Parameter(tlsBuilderType, "x");
        var block = new System.Collections.Generic.List<Expression>();

        // UseTls property or method
        var useTlsProp = tlsBuilderType.GetProperty("UseTls", BindingFlags.Public | BindingFlags.Instance);
        if (useTlsProp != null && useTlsProp.CanWrite && useTlsProp.PropertyType == typeof(bool))
        {
            block.Add(Expression.Assign(Expression.Property(p, useTlsProp), Expression.Constant(true)));
        }
        else
        {
            var useTlsMethod = tlsBuilderType.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .FirstOrDefault(m => m.Name == "UseTls" && m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType == typeof(bool));
            if (useTlsMethod != null)
                block.Add(Expression.Call(p, useTlsMethod, Expression.Constant(true)));
        }

        // CertificateValidationHandler: Func<Ctx,bool> that returns true
        var certValProp = tlsBuilderType.GetProperty("CertificateValidationHandler", BindingFlags.Public | BindingFlags.Instance);
        if (certValProp != null && certValProp.CanWrite)
        {
            var t = certValProp.PropertyType;
            if (t.IsGenericType && t.GetGenericTypeDefinition() == typeof(Func<,>))
            {
                var args = t.GetGenericArguments();
                if (args.Length == 2 && args[1] == typeof(bool))
                {
                    var ctxParam = Expression.Parameter(args[0], "ctx");
                    var alwaysTrue = Expression.Lambda(t, Expression.Constant(true), ctxParam);
                    block.Add(Expression.Assign(Expression.Property(p, certValProp), alwaysTrue));
                }
            }
        }

        // Optional bool flags (only if they exist in your MQTTnet build)
        if (ignoreTlsErrors)
        {
            AddBoolAssignIfExists(tlsBuilderType, p, block, "AllowUntrustedCertificates", true);
            AddBoolAssignIfExists(tlsBuilderType, p, block, "IgnoreCertificateChainErrors", true);
            AddBoolAssignIfExists(tlsBuilderType, p, block, "IgnoreCertificateRevocationErrors", true);
        }

        Expression body = block.Count == 0 ? Expression.Empty() : Expression.Block(block);
        var lambda = Expression.Lambda(actionType, body, p);
        return lambda.Compile();
    }

    private static void AddBoolAssignIfExists(Type tlsBuilderType, ParameterExpression p, System.Collections.Generic.List<Expression> block, string propName, bool value)
    {
        var prop = tlsBuilderType.GetProperty(propName, BindingFlags.Public | BindingFlags.Instance);
        if (prop != null && prop.CanWrite && prop.PropertyType == typeof(bool))
        {
            block.Add(Expression.Assign(Expression.Property(p, prop), Expression.Constant(value)));
        }
    }

    public async Task DisconnectAsync()
    {
        _cts?.Cancel();
        if (_client.IsConnected)
            await _client.DisconnectAsync().ConfigureAwait(false);
    }

    public async Task PublishJsonAsync(string topic, object payload, bool retain = false, int qos = 1, CancellationToken ct = default)
    {
        if (!_client.IsConnected) return;

        var json = JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true });
        var msg = new MqttApplicationMessageBuilder()
            .WithTopic(topic)
            .WithPayload(json)
            .WithRetainFlag(retain)
            .WithQualityOfServiceLevel((MQTTnet.Protocol.MqttQualityOfServiceLevel)qos)
            .Build();

        await _client.PublishAsync(msg, ct).ConfigureAwait(false);
    }
    public async Task PublishAsync(string topic, string payload, bool retain = false)
    {
        if (_client == null || !_client.IsConnected) return;

        var msg = new MqttApplicationMessageBuilder()
            .WithTopic(topic)
            .WithPayload(payload)
            .WithQualityOfServiceLevel(MQTTnet.Protocol.MqttQualityOfServiceLevel.AtLeastOnce)
            .WithRetainFlag(retain)
            .Build();

        await _client.PublishAsync(msg);
    }
    public void Dispose()
    {
        _cts?.Cancel();
        _cts?.Dispose();
        _client?.Dispose();
    }
}
