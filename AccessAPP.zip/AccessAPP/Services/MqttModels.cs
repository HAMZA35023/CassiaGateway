﻿using System.Text.Json.Serialization;

namespace AccessAPP.Services;

public enum MqttCommandType
{
    StartUpdate,
    GetFwVersion
}

public sealed class StartUpdateCommand
{
    public List<StartUpdateRequest> Requests { get; set; } = new();

    // Optional: keep for backwards compatibility if older senders used it
    public List<string> Sensors { get; set; } = new();
}


public sealed class StartUpdateRequest
{
    [JsonPropertyName("DetectorType")]
    public string? DetectorType { get; set; }

    [JsonPropertyName("FirmwareVersion")]
    public string? FirmwareVersion { get; set; }

    [JsonPropertyName("MacAddress")]
    public string? MacAddress { get; set; }

    [JsonPropertyName("Pincode")]
    public string? Pincode { get; set; }
}


public sealed class GetFwVersionCommand
{
    public List<string> Sensors { get; set; } = new();
}

public sealed class DiscoveredDevicesMessage
{
    public string Name { get; set; } = "";
    public string NetworkId { get; set; } = "";
    public DateTimeOffset Time { get; set; } = DateTimeOffset.UtcNow;

    // Placeholder structure
    public List<DiscoveredDevice> Devices { get; set; } = new();
}

public sealed class DiscoveredDevice
{
    public string Mac { get; set; } = "";
    public int? Rssi { get; set; }
    public string? DetectorType { get; set; }
    public string? DetectorFamily { get; set; }

    public string? ProductNumber { get; set; }

    public string? Name { get; set; }
}

public sealed class UpdateProgressMessage
{
    public string Name { get; set; } = "";
    public string NetworkId { get; set; } = "";
    public DateTimeOffset Time { get; set; } = DateTimeOffset.UtcNow;

    // Placeholder
    public string Mac { get; set; } = "";
    public double ProgressPercent { get; set; }
    public string? Stage { get; set; }
    public string? FirmwareTarget { get; set; }
}

public sealed class LogMessage
{
    public string Name { get; set; } = "";
    public string NetworkId { get; set; } = "";
    public DateTimeOffset Time { get; set; } = DateTimeOffset.UtcNow;

    public string Level { get; set; } = "info"; // info/warn/error/debug/verbose
    public string Message { get; set; } = "";
    public string? Mac { get; set; }
    public string? LogId { get; set; }
}

public sealed class StatusMessage
{
    public string Name { get; set; } = "";
    public string NetworkId { get; set; } = "";
    public DateTimeOffset Time { get; set; } = DateTimeOffset.UtcNow;

    public string State { get; set; } = "online"; // online/offline/etc.
    public string? Version { get; set; }
    public int queue { get; set; }

    public double totalSpeedpct { get; set; }
    }
