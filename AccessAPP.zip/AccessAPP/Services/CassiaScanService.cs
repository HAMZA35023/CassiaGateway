﻿using AccessAPP.Models;
using AccessAPP.Services.HelperClasses;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace AccessAPP.Services
{
    public class CassiaScanService
    {
        private readonly HttpClient _httpClient;
        private readonly List<ScannedDevicesView> _eventDataList;
        private readonly CassiaConnectService _cassiaConnectService;
        private readonly DeviceStorageService _deviceStorageService;
        private readonly CassiaNotificationService _notificationService;
        private readonly IConfiguration _configuration;


        public CassiaScanService(HttpClient httpClient, DeviceStorageService deviceStorageService, IConfiguration configuration, CassiaNotificationService notificationService)
        {
            _httpClient = httpClient;
            _eventDataList = new List<ScannedDevicesView>();
            _notificationService = notificationService;
            _cassiaConnectService = new CassiaConnectService(httpClient, configuration, notificationService);
            _deviceStorageService = deviceStorageService;
            _configuration = configuration;
        }

       
        public async Task<List<ScannedDevicesView>> ScanForBleDevices(string gatewayIpAddress, int gatewayPort)
        {
            try
            {
                int scanDuration = 5000;
                var uniqueDevices = new Dictionary<string, ScannedDevicesView>();

                string sseEndpoint = $"http://{gatewayIpAddress}:{gatewayPort}/gap/nodes?event=1&filter_duplicates=1&filter_mac=10:B9:F7*&active=1";
                var request = new HttpRequestMessage(HttpMethod.Get, sseEndpoint);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/event-stream"));

                using (var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead))
                {
                    response.EnsureSuccessStatusCode();

                    var cancellationTokenSource = new CancellationTokenSource(scanDuration);
                    var delayTask = Task.Delay(scanDuration, cancellationTokenSource.Token);

                    await ProcessSSEEvents(response, eventData =>
                    {
                        var mac = eventData.bdaddrs.FirstOrDefault()?.Bdaddr;
                        if (string.IsNullOrWhiteSpace(mac)) return;

                        // Use scanData if present, fallback to adData
                        var scanPayload = !string.IsNullOrEmpty(eventData.scanData)
                                          ? eventData.scanData
                                          : eventData.adData;

                        var productNumber = ScanDataParser.ExtractProductNumber(scanPayload);
                        var lockedHex = ScanDataParser.GetLockedInfo(scanPayload);
                        var isLocked = ScanDataParser.IsLocked(scanPayload);
                        var meta = ScanDataParser.GetDetectorMeta(scanPayload);
                        string name = "";

                        if (eventData.evtType == 4)
                            name = ScanDataParser.GetName(scanPayload.Substring(20, 30));

                        var enrichedDevice = new ScannedDevicesView
                        {
                            bdaddrs = eventData.bdaddrs,
                            chipId = eventData.chipId,
                            evtType = eventData.evtType,
                            rssi = eventData.rssi,
                            adData = eventData.adData,
                            scanData = eventData.scanData,
                            name = name,

                            ProductNumber = productNumber,
                            DetectorFamily = meta.DetectorFamily,
                            DetectorType = meta.DetectorType,
                            DetectorOutputInfo = meta.DetectorOutputInfo,
                            DetectorDescription = meta.DetectorDescription,
                            DetectorShortDescription = meta.DetectorShortDescription,
                            Range = meta.Range,
                            DetectorMountDescription = meta.DetectorMountDescription,
                            LockedHex = lockedHex,
                            IsLocked = isLocked
                        };

                        uniqueDevices[mac] = enrichedDevice;
                    }, cancellationTokenSource.Token);


                    await delayTask;
                }

                return uniqueDevices.Values.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error: {ex.Message + ex.StackTrace}");
            }
        }


        /// <summary>
        /// / Older Version
        /// </summary>
        /// <param name="response"></param>
        /// <param name="callback"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        //public async Task<List<ScannedDevicesView>> FetchNearbyDevices(string gatewayIpAddress, int gatewayPort, int minRssi)
        //{
        //    try
        //    {
        //        // Define the duration of each scan in milliseconds
        //        int scanDuration = 5000; // 5 seconds
        //        var nearbyDevices = new List<ScannedDevicesView>();

        //        // Step 1: Subscribe to the Server-Sent Events (SSE) endpoint
        //        string sseEndpoint = $"http://{gatewayIpAddress}:{gatewayPort}/gap/nodes?event=1";
        //        var request = new HttpRequestMessage(HttpMethod.Get, sseEndpoint);
        //        request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("text/event-stream"));

        //        using (var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead))
        //        {
        //            response.EnsureSuccessStatusCode();

        //            // Start a task to wait for 5 seconds
        //            var cancellationTokenSource = new CancellationTokenSource(scanDuration);
        //            var delayTask = Task.Delay(scanDuration, cancellationTokenSource.Token);

        //            // Step 2: Process SSE events
        //            await ProcessSSEEvents(response, eventData =>
        //            {
        //                // Parse each eventData as a ScannedDevicesView and add it to the list
        //                var device = eventData;
        //                nearbyDevices.Add(device);
        //            }, cancellationTokenSource.Token);

        //            // Wait for the scan duration or until cancellation is requested
        //            await delayTask;
        //        }

        //        var filteredDevices = nearbyDevices.Where(device => device.rssi < minRssi).ToList();
        //        return filteredDevices;
        //    }
        //    catch (OperationCanceledException)
        //    {
        //        // Handle cancellation due to timeout
        //        return new List<ScannedDevicesView>();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception($"Error: {ex.Message + ex.StackTrace}");
        //    }
        //}

        public async Task FetchNearbyDevices(string gatewayIpAddress, int gatewayPort, int minRssi)
        {
            try
            {
                // Step 1: Subscribe to the Server-Sent Events (SSE) endpoint
                string sseEndpoint = $"http://{gatewayIpAddress}:{gatewayPort}/gap/nodes?event=1";
                var request = new HttpRequestMessage(HttpMethod.Get, sseEndpoint);
                request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("text/event-stream"));

                using (var response = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead))
                {
                    response.EnsureSuccessStatusCode();

                    // Step 2: Process SSE events continuously
                    await ProcessSSEEvents(response, eventData =>
                    {
                        // Get the MAC address
                        var macAddress = eventData.bdaddrs.FirstOrDefault()?.Bdaddr;
                        if (string.IsNullOrEmpty(macAddress)) return;

                        // Check if the MAC address starts with the desired prefix (e.g., "10:B9:F7")
                        if (!macAddress.StartsWith("10:B9:F7", StringComparison.OrdinalIgnoreCase))
                        {
                            Console.WriteLine($"Skipping MAC={macAddress} as it does not match the required prefix.");
                            return; // Skip the processing for this MAC address
                        }


                        // Log the received event
                        Console.WriteLine($"Received Event: MAC={macAddress}, RSSI={eventData.rssi}");

                        // Add or update the device in the global storage if it meets the RSSI threshold
                        _deviceStorageService.AddOrUpdateDevice(eventData, minRssi);
                    }, CancellationToken.None);  // Using CancellationToken.None for infinite processing
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error: {ex.Message + ex.StackTrace}");
            }
        }



        private async Task ProcessSSEEvents(HttpResponseMessage response, Action<ScannedDevicesView> callback, CancellationToken cancellationToken)
        {
            try
            {
                using (var stream = await response.Content.ReadAsStreamAsync())
                using (var reader = new System.IO.StreamReader(stream))
                {
                    while (!reader.EndOfStream)
                    {
                        // Check for cancellation before reading the next line
                        cancellationToken.ThrowIfCancellationRequested();

                        string line = await reader.ReadLineAsync();
                        // Process the SSE event
                        //Console.WriteLine(line);

                        if (!string.IsNullOrEmpty(line) && line != "" && line != ":keep-alive")
                        {
                            if (line.StartsWith("data:"))
                            {
                                line = line.Substring("data:".Length).Trim();
                            }
                            // Parse the JSON data from the SSE event
                            var eventData = JsonConvert.DeserializeObject<ScannedDevicesView>(line);
                            callback(eventData); // Call the callback with the parsed data
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
                // Handle cancellation due to timeout
                Console.WriteLine("SSE event processing canceled due to timeout.");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error processing SSE events: {ex.Message + ex.StackTrace}");
            }
        }
    }
}
