﻿public class CassiaReadWriteService : IDisposable
{
    private static readonly HttpClient httpClient = new HttpClient();
    public SemaphoreSlim semaphore = null;

    public async Task<HttpResponseMessage> WriteBleMessage(string gatewayIpAddress, string macAddress, int handle, string hexValue, string queryParams)
    {
        await semaphore.WaitAsync(); // Wait until it's safe to proceed
        try
        {
            string endpoint = $"http://{gatewayIpAddress}/gatt/nodes/{macAddress}/handle/{handle}/value/{hexValue}{queryParams}";
            var request = new HttpRequestMessage(HttpMethod.Get, endpoint);
            using (var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead))
            {
                if (!response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Bad Write reason: " + response.Content.ReadAsStringAsync());
                }

                response.EnsureSuccessStatusCode();
                return response;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error {macAddress}: {ex.Message + ex.StackTrace}");
            throw new Exception($"Error: {ex.Message + ex.StackTrace}");
        }
        finally
        {
            semaphore.Release(); // Release the semaphore
        }
    }

    public void Dispose()
    {
       // httpClient?.Dispose();
    }
}
